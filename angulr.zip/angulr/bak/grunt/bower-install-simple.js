module.exports = {
    options: {
        color: false,
        production: false,
        directory: 'bower_components'
    }
};