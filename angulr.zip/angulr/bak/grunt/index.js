var requireDirectory = require('require-directory');
module.exports = requireDirectory(module);